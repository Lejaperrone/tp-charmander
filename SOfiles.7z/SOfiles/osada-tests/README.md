# OSADA Tests

Set de scripts en BASH para validar limites y consistencia sobre el FS OSADA

